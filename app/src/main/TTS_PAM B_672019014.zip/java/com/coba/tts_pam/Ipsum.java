package com.coba.tts_pam;

import java.util.ArrayList;

public class Ipsum {

    static ArrayList <ArticleItems> listData = new ArrayList<>();

}
